#!/bin/bash

mail -s "你好" 528909316@qq.com </server/scripts/youxiang/wenjian.txt
