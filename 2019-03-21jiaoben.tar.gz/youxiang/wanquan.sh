#!/bin/bash

while true
do
((i=i+1))
echo $i

if [ $i = 30 ]
then
sleep 10

fi
done
