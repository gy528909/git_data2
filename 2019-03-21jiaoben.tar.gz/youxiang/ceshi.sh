#!/bin/bash

while true
do
((i=i+30))
echo "$i"

done
