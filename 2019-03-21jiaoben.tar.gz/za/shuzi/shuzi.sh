#!/bin/bash

i=1
o=0

while true ;do
	u=[$o+$i]
	i=$[$i+1]
	echo   $i
done
