#!/bin/bash

i=1
JJ=0

while true
do
hh=[$jj+$i]
i=$[$i+1]
	bash /server/scripts/youxiang/fasong.sh
	echo ================={1..5}
	echo     $hh
	sleep 1
done


