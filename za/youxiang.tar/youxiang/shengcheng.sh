#!/bin/bash

while true
do
echo "党凯真帅"
#sleep 1
done
